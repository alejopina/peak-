# Peak Hobbies Website

This is the complete static website build for Peak Hobbies.

## Preview it
On a computer, unzip the folder and double-click `index.html`.

## Publish it free with GitHub Pages
1. Go to GitHub and create a new repository named `peak-hobbies`.
2. Choose **Add file → Upload files**.
3. Upload every file from this folder, not the ZIP itself.
4. Commit the files.
5. Open **Settings → Pages**.
6. Under **Build and deployment**, select **Deploy from a branch**.
7. Select `main` and `/ (root)`, then press **Save**.
8. GitHub will display the public website link after deployment.

## Included
- Cinematic RC crawler opening
- Responsive mobile navigation
- Product/category sections
- Interactive featured-product slider
- Staff picks and community gallery
- Events section
- Maps, directions and phone buttons
- Favicon, web app manifest and 404 page

## Before a real business launch
Replace stock photography, sample events, collection links and the temporary hours message with approved store content.
