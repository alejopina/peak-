const intro=document.querySelector("#intro"),skip=document.querySelector("#skipIntro");
const finishIntro=()=>{intro?.classList.add("done");document.body.classList.remove("intro-lock");sessionStorage.setItem("peakIntro","seen")};
if(sessionStorage.getItem("peakIntro")==="seen"){finishIntro()}else{setTimeout(finishIntro,4200)}
skip?.addEventListener("click",finishIntro);

const menu=document.querySelector(".menu-toggle"),nav=document.querySelector(".nav");
menu?.addEventListener("click",()=>{const open=nav.classList.toggle("open");menu.setAttribute("aria-expanded",String(open))});
document.querySelectorAll(".nav a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");menu?.setAttribute("aria-expanded","false")}));

const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add("visible");observer.unobserve(e.target)}}),{threshold:.14});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

const slides=[
 {badge:"STAFF FAVORITE",title:"A CRAWLER YOU CAN GROW WITH",text:"Beginner-friendly out of the box, capable enough for weekend adventures and easy to personalize when the upgrade bug bites.",tags:["Beginner Friendly","Upgradeable","Weekend Ready"],image:"https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?auto=format&fit=crop&w=1500&q=90"},
 {badge:"JUST FOR FUN",title:"TURN THE BACKYARD INTO A RACETRACK",text:"Durable, quick and uncomplicated—the kind of RC truck that makes everyone ask for a turn.",tags:["Fast","Durable","Ready to Run"],image:"https://images.unsplash.com/photo-1503736334956-4c8f8e92946d?auto=format&fit=crop&w=1500&q=90"},
 {badge:"TAKE FLIGHT",title:"YOUR FIRST AIRCRAFT DOESN'T HAVE TO BE SCARY",text:"Start with a stable, forgiving model and get straightforward help with batteries, setup and your first flight.",tags:["Stable","Easy Setup","Beginner Pick"],image:"https://images.unsplash.com/photo-1436491865332-7a61a109cc05?auto=format&fit=crop&w=1500&q=90"},
 {badge:"GAME NIGHT",title:"ONE BOX. A WHOLE NIGHT OF FUN.",text:"A replayable tabletop favorite that is easy to teach and fun for friends, families and seasoned players.",tags:["Family Friendly","Replayable","Easy to Learn"],image:"https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?auto=format&fit=crop&w=1500&q=90"}
];
let current=0;
const photo=document.querySelector("#newPhoto"),badge=document.querySelector("#newBadge"),index=document.querySelector("#newIndex"),title=document.querySelector("#newTitle"),text=document.querySelector("#newText"),tags=document.querySelector("#newTags");
function render(){const s=slides[current];photo.style.backgroundImage=`linear-gradient(rgba(0,0,0,.08),rgba(0,0,0,.18)),url("${s.image}")`;badge.textContent=s.badge;index.textContent=String(current+1).padStart(2,"0");title.textContent=s.title;text.textContent=s.text;tags.innerHTML=s.tags.map(t=>`<span>${t}</span>`).join("")}
document.querySelector("#newNext")?.addEventListener("click",()=>{current=(current+1)%slides.length;render()});
document.querySelector("#newPrev")?.addEventListener("click",()=>{current=(current-1+slides.length)%slides.length;render()});
render();